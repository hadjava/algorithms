"use strict";

// Получение входных данных от пользователя
var num1 = parseInt(prompt("Введите первое число:"));
var num2 = parseInt(prompt("Введите второе число:"));
var num3 = parseInt(prompt("Введите третье число:"));

// Вычисление суммы трех чисел
var sum = num1 + num2 + num3;

// Вывод суммы в консоль
console.log("Сумма трех чисел: " + sum);


var resultDiv = document.getElementById("result");
resultDiv.innerHTML = "Сумма трех чисел: " + sum;


